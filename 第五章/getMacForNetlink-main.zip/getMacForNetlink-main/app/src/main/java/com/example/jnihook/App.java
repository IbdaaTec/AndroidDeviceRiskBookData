package com.example.jnihook;

import android.app.Application;


/**
 * @author Zhenxi on 2022/1/17
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
