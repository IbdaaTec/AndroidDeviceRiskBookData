//
// Created by Zhenxi on 2023/2/23.
//
#include <string>

#include <linux/prctl.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <cerrno>

#include "tracee/tracee.h"
#include "Log.h"
#include "event.h"
#include "seccomp.h"
#include "note.h"
#include "proot.h"
#include "binding.h"
#include "canon.h"

#define PARENT_EXE_NAME "zygote"

using namespace std;

void initSignHandler(){
    struct sigaction signal_action;
    long status;
    int signum;

    /* Kill all tracees when exiting.  */
    status = atexit(kill_all_tracees);
    if (status != 0)
        note(NULL, WARNING, INTERNAL, "atexit() failed");

    /* All signals are blocked when the signal handler is called.
     * SIGINFO is used to know which process has signaled us and
     * RESTART is used to restart waitpid(2) seamlessly.  */
    bzero(&signal_action, sizeof(signal_action));
    signal_action.sa_flags = SA_SIGINFO | SA_RESTART;
    status = sigfillset(&signal_action.sa_mask);
    if (status < 0)
        note(NULL, WARNING, SYSTEM, "sigfillset()");

    /* Handle all signals.  */
    for (signum = 0; signum < SIGRTMAX; signum++) {
        switch (signum) {
            case SIGQUIT:
            case SIGILL:
            case SIGABRT:
            case SIGFPE:
            case SIGSEGV:
                /* Kill all tracees on abnormal termination
                 * signals.  This ensures no process is left
                 * untraced.  */
                signal_action.sa_sigaction = kill_all_tracees2;
                break;

            case SIGUSR1:
            case SIGUSR2:
                /* Print on stderr the complete talloc
                 * hierarchy, useful for debug purpose.  */
                signal_action.sa_sigaction = print_talloc_hierarchy;
                break;

            case SIGCHLD:
            case SIGCONT:
            case SIGSTOP:
            case SIGTSTP:
            case SIGTTIN:
            case SIGTTOU:
                /* The default action is OK for these signals,
                 * they are related to tty and job control.  */
                continue;

            default:
                /* Ignore all other signals, including
                 * terminating ones (^C for instance). */
                signal_action.sa_sigaction = reinterpret_cast<void (*)(int, siginfo *, void *)>(SIG_IGN);
                break;
        }

        status = sigaction(signum, &signal_action, NULL);
        if (status < 0 && errno != EINVAL)
            note(NULL, WARNING, SYSTEM, "sigaction(%d)", signum);
    }
}




/**
 * Initialize @tracee's current working directory.  This function
 * returns -1 if an error occurred, otherwise 0.
 */
static int initialize_cwd(Tracee *tracee)
{
    char path2[PATH_MAX];
    char path[PATH_MAX];
    int status;

    /* Compute the base directory.  */
    if (tracee->fs->cwd[0] != '/') {
        status = getcwd2(tracee->reconf.tracee, path);
        if (status < 0) {
            note(tracee, ERROR, INTERNAL, "getcwd: %s", strerror(-status));
            return -1;
        }
    }
    else
        strcpy(path, "/");

    /* The ending "." ensures canonicalize() will report an error
     * if tracee->fs->cwd does not exist or if it is not a
     * directory.  */
    status = join_paths(3, path2, path, tracee->fs->cwd, ".");
    if (status < 0) {
        note(tracee, ERROR, INTERNAL, "getcwd: %s", strerror(-status));
        return -1;
    }

    /* Initiale state for canonicalization.  */
    strcpy(path, "/");

    status = canonicalize(tracee, path2, true, path, 0);
    if (status < 0) {
        note(tracee, WARNING, USER, "can't chdir(\"%s\") in the guest rootfs: %s",
             path2, strerror(-status));
        note(tracee, INFO, USER, "default working directory is now \"/\"");
        strcpy(path, "/");
    }
    chop_finality(path);

    /* Replace with the canonicalized working directory.  */
    TALLOC_FREE(tracee->fs->cwd);
    tracee->fs->cwd = talloc_strdup(tracee->fs, path);
    if (tracee->fs->cwd == nullptr)
        return -1;
    talloc_set_name_const(tracee->fs->cwd, "$cwd");

    /* Keep this special environment variable consistent.  */
    setenv("PWD", path, 1);

    return 0;
}


void trace_current_process(const string& root_path){

    int status;
    prctl(PR_SET_DUMPABLE, 1, 0, 0, 0);
    auto mainPid = getpid();
    //init first tracer
    auto *first = get_tracee(nullptr, mainPid, true);
    first->pid = getpid();
    first->verbose = 2;

/*    //设置绑定根目录信息
    handle_option_r(first,nullptr,root_path.c_str());
    //绑定常用根目录信息
    handle_option_b(first,nullptr,"/etc/");
    handle_option_b(first,nullptr,"/dev/");
    handle_option_b(first,nullptr,"/sys/");
    handle_option_b(first,nullptr,"/system/");*/

    status = pre_initialize_bindings(first, nullptr,0, nullptr,0);
    if (status < 0)
        return;

    handle_option_b(first,nullptr,"/proc/");

    /* The guest rootfs is now known: bindings specified by the
     * user (tracee->bindings.user) can be canonicalized.
     * 现在已经知道了guest rootfs：用户指定的绑定（tracee->bindings.user）可以被规范化。
     * */
    status = initialize_bindings(first);
    if (status < 0)
        return;

    status = initialize_cwd(first);
    if (status < 0)
        return;

    // 计算first->fs->bindings的长度


    LOGI("init sandbox path finish ")

    pid_t child = fork();
    if (child < 0) {
        LOGE("ptrace svc  fork() error %s ", strerror(errno))
        return;
    }
    if (child == 0) {
        //try set tracer process name
        prctl(PR_SET_NAME, PARENT_EXE_NAME);
        LOGI("fork  set process name  success ")

        // 当PTRACE_ATTACH 以后被pid的进程进入阻塞状态,主线程进入阻塞状态,等待CONT信号
        long status = ptrace(PTRACE_ATTACH, mainPid, NULL, NULL);
        if (status != 0) {
            ALOGE(">>>>>>>>> error: attach target process %lu ", status)
            kill(getpid(), 9);
            return;
        }
        LOGI("ptrace main success ! ")

        first->wait_sigcont = true;

        //first->wait_sigcont = true;
        exit(event_loop());
    } else{
        //initSignHandler();
        //init by main process
        //the seccomp filtering rule is intended only for the current process
        enable_syscall_filtering(first);
    }
    ALOGE(">>>>>>>>> trace_current_process init finish  !!! ")
}