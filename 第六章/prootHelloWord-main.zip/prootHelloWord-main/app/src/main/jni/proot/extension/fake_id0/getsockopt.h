#ifndef FAKE_ID0_GETSOCKOPT_H
#define FAKE_ID0_GETSOCKOPT_H

#include "tracee/tracee.h"

int handle_getsockopt_exit_end(Tracee *tracee);

#endif /* FAKE_ID0_GETSOCKOPT_H */
