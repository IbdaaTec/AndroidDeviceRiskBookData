//
// Created by Zhenxi on 2023/2/23.
//
#include <string>


void trace_current_process(const std::string& path);