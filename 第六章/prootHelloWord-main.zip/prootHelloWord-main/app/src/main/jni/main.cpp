

#include <jni.h>


#include "utils/Log.h"
#include "proot/prootEngine.h"

using namespace std;

string jstring2str(JNIEnv *env, jstring jstr) {
    char *rtn = nullptr;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("UTF-8");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    auto barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte *ba = env->GetByteArrayElements(barr, JNI_FALSE);
    if (alen > 0) {
        rtn = (char *) malloc(alen + 1);
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    std::string stemp(rtn);
    free(rtn);
    return stemp;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_jnihook_MainActivity_TestNative(JNIEnv *env, jobject thiz) {


}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_jnihook_MainActivity_startTraceeProcess(JNIEnv *env,jobject thiz,
                                                         jstring root_path
                                                         ) {
    auto path = jstring2str(env, root_path);
    trace_current_process(path);
}