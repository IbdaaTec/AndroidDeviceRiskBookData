package com.example.jnihook;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;


public class MainActivity extends Activity {

    static {
        System.loadLibrary("helloword");
    }

    public native void startTraceeProcess(String root_path);

    public native void TestNative();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        File file =
                new File("/data/data/" + getPackageName() + "/app_virtual_devices/test/");
        file.mkdirs();
        startTraceeProcess(file.getPath());

        TestNative();

    }

}